#ifndef ARCUS_DOOR_H
#define ARCUS_DOOR_H

namespace arcus {
	class Item;
	class OnOffItem;
	class Door: public Item, public OnOffItem {
	
	};

}

#endif