#include <string>

#include "userinterface.h"
#include "world.h"

std::string msg = "What do you do?";

int main() {
	arcus::World world;
	world.start();
	
}